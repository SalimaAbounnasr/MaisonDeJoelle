// Defining this will trick dist/underscore.string.js into putting its exports into module.exports
// Credit to Tim Heckel for this trick - see https://github.com/TimHeckel/meteor-underscore-string
module = {};

// This also needed, otherwise above doesn't work???
exports = {};

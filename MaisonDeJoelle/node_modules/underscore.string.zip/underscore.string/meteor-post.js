// s will be picked up by Meteor and exported
s = module.exports;
